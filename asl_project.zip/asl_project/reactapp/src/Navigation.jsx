import React from 'react'
import { Link } from 'react-router-dom';

class Navigation extends React.Component
{
	render() {
		return (
			<div styles = {styles.nav}>
			<header>
				<ul>
					<li><Link to="/">Home</Link></li>
					{this.props.isLoggedIn && <li><Link to="/logout">Logout</Link></li>}
				</ul>
			</header>
			</div>
		);
	}
}

export default Navigation;

const styles ={
    nav:{
        display: 'flex',
        flexDirection:'column',
        alignItems: 'center',
        width: '250px',
        padding: '1%',
        backgroundColor:'black',
        color: 'rgb(163,173,194)',
        boxShadow:'0 4px 8px 0 rgba(0, 0, 0.19)',
        textAlign:'center',
    },
    
}