import React, {useState,useEffect} from "react";
import { Link } from 'react-router-dom'
import queryString from 'querystring'
import axios from 'axios'

const Home = () =>{
    const [quizzes, setQuizzes] = useState([])
    useEffect(()=>{
        async function fetchQuizzes(){
            const params =queryString.parse(window.location.search.replace(/^\?/, ''))
            const response = await axios ('http://localhost:3333/quizzes',{
                headers:{
                    token: localStorage.token
                }
            })
            setQuizzes(response.data)
        }
        fetchQuizzes()
    }, []);
    return(
        <div>
            <h1>Welcome!</h1>
            <h2>Let's Take a Quiz!</h2>
            <p>Click on any of the following quizzes to get started</p>
            <ul>
                {quizzes.map(q =>{
                    <li>
                        <Link to={'/quizzes/' + q.id}>{q.name}</Link>
                    </li>
                })}
            </ul>
        </div>
    )
}

export default Home
  
