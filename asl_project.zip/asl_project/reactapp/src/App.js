import './App.css';
import axios from 'axios';
import queryString from 'querystring';
import {
  BrowserRouter as Router,
  Route,
  Routes
} from 'react-router-dom';
import Home from './Home';
import Login from './Login';
import Quiz from './Quiz';
import Navigation from './Navigation';
import { useEffect, useState } from 'react';

const App =() =>{
  const [thing, setThing] = useState('')
  useEffect(()=>{
    async function fetchThing(){
      const params = queryString.parse(window.location.search.replace(/^\?/, ''))
      localStorage.token = params.token
      const response = await axios('http://localhost:3333/auth/token/',{
        headers: {
          token: localStorage.token
        }
      })
      setThing(response.data.token)
    }
    fetchThing()
  }, []);

  if (!thing){
    return <Login />;
  }
  return (
    <Router>
      <div>
        < Navigation isLoggedIn = {thing ? true : false } />
        <Routes>
          <Route exact path='/' element={<Home />} />
          <Route exact path = '/quizzes/:id' element = {<Quiz/>} />
        </Routes> 
      </div>
    </Router>
  )
}

export default App;
