import React from "react";

class Login extends React.Component
{
    render(){
        return (
            <div styles= {styles.main}>
                <h1>Log In</h1>
                <p>Please log in with github by clicking on the link below:</p>
                <a href="https://github.com/login/oauth/authorize?client_id=f9126f0ebd7e06020173">Log in with GitHub</a>
            </div>
        )
    }
}

export default Login

const styles ={
    main:{
        display: 'flex',
        flexDirection:'column',
        alignItems: 'center',
        width: '250px',
        padding: '1%',
        backgroundColor:'black',
        color: 'rgb(163,173,194)',
        boxShadow:'0 4px 8px 0 rgba(0, 0, 0.19)',
        textAlign:'center',
    }
    
}